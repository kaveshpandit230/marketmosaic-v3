<?php
// MarketMosaic AI assistant. Copy this file to config/ai.php and paste your Claude API key.
// Get a key at https://console.anthropic.com (Settings → API keys). Usage is billed by Anthropic per token.
declare(strict_types=1);

return [
    'api_key' => 'replace_with_your_claude_api_key',
    'model' => 'claude-sonnet-5-5',   // or 'claude-haiku-5-5' for lower cost and faster replies
    'max_tokens' => 2048,
];
