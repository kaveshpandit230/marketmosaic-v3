<?php
/**
 * MarketMosaic AI assistant: helps users connect lead sources and acts on their CRM through tools.
 * Uses the Claude Messages API (tool use). Configure in config/ai.php (copy config/ai.example.php).
 */

declare(strict_types=1);

// ── providers (shared by the Integrations tab and the assistant) ──────────
const MM_PROVIDERS = [
    'whatsapp'  => ['name' => 'WhatsApp', 'sources' => ['WhatsApp'], 'keyword' => 'whatsapp', 'native' => 'live'],
    'facebook'  => ['name' => 'Facebook lead ads', 'sources' => ['Facebook'], 'keyword' => 'facebook', 'native' => 'zapier'],
    'instagram' => ['name' => 'Instagram', 'sources' => ['Instagram'], 'keyword' => 'instagram', 'native' => 'link'],
    'google'    => ['name' => 'Google Ads lead forms', 'sources' => ['Google'], 'keyword' => 'google', 'native' => 'webhook'],
    'website'   => ['name' => 'Website forms', 'sources' => ['Website'], 'keyword' => 'website', 'native' => 'live'],
    'linkedin'  => ['name' => 'LinkedIn lead gen', 'sources' => ['LinkedIn'], 'keyword' => 'linkedin', 'native' => 'zapier'],
    'indiamart' => ['name' => 'IndiaMART / JustDial / portals', 'sources' => ['IndiaMART', 'JustDial', 'Other'], 'keyword' => 'indiamart', 'native' => 'zapier'],
    'zapier'    => ['name' => 'Zapier / Make', 'sources' => [], 'keyword' => 'zapier', 'native' => 'zapier'],
];

const MM_SETUP_GUIDES = [
    'google' => "Google Ads lead form webhook (native, about 3 minutes):\n1. Create a connection key (tool create_connection_key with provider google).\n2. In Google Ads open Assets → Lead forms → your form (or create one on a Search, Performance Max, YouTube or Demand Gen campaign).\n3. Scroll to 'Export leads from Google Ads' → 'Other data integration options' → 'Use a webhook'.\n4. Paste the Webhook URL and the Key, save, then press 'Send test data'.\n5. A test lead appears in MarketMosaic Leads within seconds, with source Google and the campaign name.",
    'facebook' => "Facebook and Instagram lead ads (Instant forms) via Zapier (about 10 minutes, free Zapier plan works for low volume):\n1. Create a connection key (provider facebook).\n2. In Zapier, Create Zap → trigger 'Facebook Lead Ads' → 'New Lead'; connect the Facebook page and pick the form.\n3. Action 'Webhooks by Zapier' → 'POST'. URL = the POST URL. Payload type = json.\n4. Data: name, email, phone, company (map from the form fields), source = Facebook (or Instagram), utm_campaign = the ad campaign name.\n5. Headers: X-Api-Key = the key.\n6. Test the step; the lead appears in MarketMosaic. Publish the Zap.\nInstant-form ads that run on Instagram arrive through the same Facebook page connection.",
    'instagram' => "Instagram without ads: use a tracked link (tool get_tracked_link with channel instagram) in the bio, stories link sticker, reels caption or DMs. Every enquiry is captured, scored and tagged Instagram.\nInstagram lead ads (Instant forms) come through the Facebook lead ads connection.",
    'whatsapp' => "WhatsApp today:\n1. Every lead has one-tap WhatsApp with ready message templates (already live).\n2. Put a tracked enquiry link (tool get_tracked_link with channel whatsapp) in the WhatsApp Business profile, catalogue, status and the automatic greeting message, so chats become scored leads.\n3. Click-to-WhatsApp ads: add the same link to the ad's welcome message.\nAutomatic WhatsApp replies through the WhatsApp Business API are on the roadmap (needs Meta business verification).",
    'website' => "Website forms (live):\n1. Use the hosted form link (tool get_tracked_link with channel website) on buttons such as 'Get a quote'.\n2. Or paste the embed code (tool get_embed_code) into the page: WordPress → edit page → add a 'Custom HTML' block → paste. Wix/Squarespace → Embed HTML block.\n3. Spam is filtered automatically; duplicates by email are merged.",
    'linkedin' => "LinkedIn Lead Gen Forms via Zapier:\n1. Create a connection key (provider linkedin).\n2. Zapier trigger 'LinkedIn Ads' → 'New Lead Gen Form Response'.\n3. Action 'Webhooks by Zapier' → POST to the POST URL, json, fields name/email/phone/company, source = LinkedIn; header X-Api-Key = key.",
    'indiamart' => "IndiaMART, JustDial, 99acres and other portals:\n1. Create a connection key (provider indiamart).\n2. If the portal is available in Zapier, use it as the trigger; otherwise use 'Email Parser by Zapier' on the portal's enquiry emails.\n3. Action 'Webhooks by Zapier' → POST to the POST URL with name, email, phone, message and source (for example IndiaMART); header X-Api-Key = key.\nNote: leads need an email address; if the portal gives only a phone number, map a placeholder email such as <phone>@lead.marketmosaic.co.in.",
    'zapier' => "Any other app via Zapier or Make:\n1. Create a connection key (provider zapier).\n2. Trigger = the app's 'new lead/enquiry' event.\n3. Action = Webhooks → POST, json, to the POST URL with fields name, email (required), phone, company, source, message, utm_source, utm_medium, utm_campaign; header X-Api-Key = key.",
];

function mm_provider_status(int $userId): array
{
    $keys = array_map(fn($r) => strtolower((string) $r['name']),
        fetch_all('SELECT name FROM api_tokens WHERE user_id = :u', [':u' => $userId]));
    $bySource = [];
    foreach (fetch_all("SELECT source, COUNT(*) AS n, MAX(created_at) AS last_at,
                               SUM(created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)) AS n30
                        FROM leads WHERE owner_user_id = :u GROUP BY source", [':u' => $userId]) as $r) {
        $bySource[strtolower((string) $r['source'])] = $r;
    }
    $forms = (int) (fetch_one('SELECT COUNT(*) AS n FROM lead_forms WHERE created_by = :u AND active = 1', [':u' => $userId])['n'] ?? 0);
    $out = [];
    foreach (MM_PROVIDERS as $key => $p) {
        $leads30 = 0;
        $last = null;
        foreach ($p['sources'] as $s) {
            $r = $bySource[strtolower($s)] ?? null;
            if ($r) {
                $leads30 += (int) $r['n30'];
                $last = max((string) $last, (string) $r['last_at']) ?: null;
            }
        }
        $hasKey = (bool) array_filter($keys, fn($k) => str_contains($k, $p['keyword']) || ($key === 'facebook' && str_contains($k, 'meta')));
        $status = match (true) {
            $leads30 > 0 => 'receiving',
            $hasKey, ($key === 'website' && $forms > 0) => 'connected',
            $p['native'] === 'live' => 'ready',
            default => 'not_connected',
        };
        $out[] = ['key' => $key, 'name' => $p['name'], 'status' => $status, 'leads_30d' => $leads30, 'last_lead_at' => $last,
                  'method' => $p['native'], 'has_key' => $hasKey, 'forms' => $key === 'website' ? $forms : null];
    }
    return $out;
}

/** First active capture form of the user, created if missing. */
function mm_default_form(int $userId): array
{
    $form = fetch_one('SELECT * FROM lead_forms WHERE created_by = :u AND active = 1 ORDER BY submissions DESC, id LIMIT 1', [':u' => $userId]);
    if ($form) {
        return $form;
    }
    execute_query("INSERT INTO lead_forms (name, public_key, source, heading, intro, button_text, ask_phone, ask_company, ask_message, active, created_by, created_at)
                   VALUES ('Enquiry form', :k, 'Website', 'Tell us what you need', 'Share your details and we will call you back shortly.', 'Send enquiry', 1, 1, 1, 1, :u, NOW())",
        [':k' => substr(bin2hex(random_bytes(8)), 0, 12), ':u' => $userId]);
    return fetch_one('SELECT * FROM lead_forms WHERE id = :id', [':id' => (int) db()->lastInsertId()]);
}

// ── tools ─────────────────────────────────────────────────
function mm_tool_defs(): array
{
    $prov = array_keys(MM_PROVIDERS);
    $obj = fn(array $props = [], array $req = []) => ['type' => 'object', 'properties' => (object) $props] + ($req ? ['required' => $req] : []);
    return [
        ['name' => 'get_integration_status', 'description' => 'Status of every lead source for this user: receiving leads, connected, ready, or not connected, with leads in the last 30 days.', 'input_schema' => $obj()],
        ['name' => 'get_setup_guide', 'description' => 'Exact step-by-step setup instructions for connecting a lead source.', 'input_schema' => $obj(['provider' => ['type' => 'string', 'enum' => $prov]], ['provider'])],
        ['name' => 'create_connection_key', 'description' => 'Create a private API key and return the webhook/POST URL for a provider. The user sees the key and URL as copy buttons. Use only when the user is ready to connect.', 'input_schema' => $obj(['provider' => ['type' => 'string', 'enum' => $prov]], ['provider'])],
        ['name' => 'get_tracked_link', 'description' => 'Get a lead-capture link tagged for a channel (instagram, whatsapp, website, facebook, google, linkedin, qr, sms, email). Creates a default enquiry form if the user has none.', 'input_schema' => $obj(['channel' => ['type' => 'string'], 'medium' => ['type' => 'string', 'description' => 'e.g. bio, story, status, catalogue, post, ad'], 'campaign' => ['type' => 'string', 'description' => 'optional campaign code']], ['channel'])],
        ['name' => 'get_embed_code', 'description' => 'HTML embed code for the website capture form.', 'input_schema' => $obj()],
        ['name' => 'send_test_lead', 'description' => 'Create a clearly labelled test lead from a provider to prove the pipeline works.', 'input_schema' => $obj(['provider' => ['type' => 'string', 'enum' => $prov]], ['provider'])],
        ['name' => 'search_leads', 'description' => 'Find the user\'s leads. Returns up to 20.', 'input_schema' => $obj(['q' => ['type' => 'string'], 'grade' => ['type' => 'string', 'enum' => ['hot', 'warm', 'cold']], 'status' => ['type' => 'string', 'enum' => ['New', 'Contacted', 'Qualified', 'Unqualified', 'Converted']], 'source' => ['type' => 'string']])],
        ['name' => 'get_analytics', 'description' => 'KPIs, funnel, best sources and campaign ROI for a period.', 'input_schema' => $obj(['days' => ['type' => 'integer', 'enum' => [30, 90, 365, 0]]])],
        ['name' => 'create_campaign', 'description' => 'Create a marketing campaign so leads can be attributed and ROI tracked. Returns its utm_campaign code.', 'input_schema' => $obj(['name' => ['type' => 'string'], 'channel' => ['type' => 'string', 'enum' => ['Ads', 'WhatsApp', 'Email', 'LinkedIn', 'Phone', 'Event']], 'budget' => ['type' => 'number'], 'spent' => ['type' => 'number']], ['name', 'channel'])],
        ['name' => 'create_task', 'description' => 'Create a follow-up task, optionally on a lead.', 'input_schema' => $obj(['title' => ['type' => 'string'], 'due_date' => ['type' => 'string', 'description' => 'YYYY-MM-DD'], 'lead_id' => ['type' => 'integer'], 'priority' => ['type' => 'string', 'enum' => ['low', 'medium', 'high']]], ['title'])],
        ['name' => 'update_lead_status', 'description' => 'Change a lead\'s status (not for converting to a deal).', 'input_schema' => $obj(['lead_id' => ['type' => 'integer'], 'status' => ['type' => 'string', 'enum' => ['New', 'Contacted', 'Qualified', 'Unqualified']]], ['lead_id', 'status'])],
        ['name' => 'whatsapp_links', 'description' => 'Prepare personalised WhatsApp messages for leads. Use {first_name} in the message. Returns one tap-to-send button per lead.', 'input_schema' => $obj(['lead_ids' => ['type' => 'array', 'items' => ['type' => 'integer']], 'message' => ['type' => 'string']], ['lead_ids', 'message'])],
    ];
}

function mm_lead_brief(array $l): array
{
    return ['id' => (int) $l['id'], 'name' => $l['name'], 'phone' => $l['phone'], 'email' => $l['email'], 'company' => $l['company_name'],
            'source' => $l['source'], 'status' => $l['status'], 'grade' => $l['grade'], 'score' => (int) $l['score'], 'created_at' => $l['created_at']];
}

/** Runs one tool. Returns [result for the model, cards for the app]. */
function mm_run_tool(string $name, array $in, array $user): array
{
    $uid = (int) $user['id'];
    $cards = [];
    switch ($name) {
        case 'get_integration_status':
            return [['providers' => mm_provider_status($uid)], []];

        case 'get_setup_guide':
            $p = (string) ($in['provider'] ?? '');
            return [['provider' => $p, 'steps' => MM_SETUP_GUIDES[$p] ?? 'No guide for this provider.'], []];

        case 'create_connection_key':
            $p = (string) ($in['provider'] ?? 'zapier');
            $label = MM_PROVIDERS[$p]['name'] ?? 'Integration';
            $token = lg_create_token($uid, $label . ' (assistant)');
            $url = lg_public_url($p === 'google' ? 'api/v1/?r=google_lead' : 'api/v1/?r=leads');
            $cards[] = ['kind' => 'copy', 'label' => $p === 'google' ? 'Webhook URL' : 'POST URL', 'value' => $url];
            $cards[] = ['kind' => 'copy', 'label' => $p === 'google' ? 'Key' : 'X-Api-Key header', 'value' => $token];
            return [['created' => true, 'url' => $url, 'key_hint' => '…' . substr($token, -6),
                     'note' => 'The full key and URL are shown to the user as copy buttons. Do not repeat the key in your reply.'], $cards];

        case 'get_tracked_link':
            $form = mm_default_form($uid);
            $channel = strtolower(preg_replace('/[^a-z0-9_-]/i', '', (string) ($in['channel'] ?? 'website')) ?: 'website');
            $q = ['k' => $form['public_key'], 'utm_source' => $channel];
            if (!empty($in['medium'])) $q['utm_medium'] = lg_slug((string) $in['medium']);
            if (!empty($in['campaign'])) $q['utm_campaign'] = lg_slug((string) $in['campaign']);
            $url = lg_public_url('f.php?' . http_build_query($q));
            $nice = ['whatsapp' => 'WhatsApp', 'linkedin' => 'LinkedIn', 'qr' => 'QR code', 'sms' => 'SMS', 'indiamart' => 'IndiaMART'][$channel] ?? ucfirst($channel);
            $cards[] = ['kind' => 'copy', 'label' => $nice . ' link', 'value' => $url];
            $cards[] = ['kind' => 'link', 'label' => 'Preview form', 'url' => $url];
            return [['url' => $url, 'form' => $form['name']], $cards];

        case 'get_embed_code':
            $form = mm_default_form($uid);
            $src = lg_public_url('f.php?k=' . $form['public_key'] . '&utm_source=website&embed=1');
            $code = '<iframe src="' . $src . '" style="width:100%;max-width:520px;height:600px;border:0" title="' . htmlspecialchars((string) $form['heading'], ENT_QUOTES) . '"></iframe>';
            $cards[] = ['kind' => 'copy', 'label' => 'Embed code', 'value' => $code];
            return [['embed_code_shown_to_user' => true, 'form' => $form['name']], $cards];

        case 'send_test_lead':
            $p = (string) ($in['provider'] ?? 'website');
            $src = MM_PROVIDERS[$p]['sources'][0] ?? 'Website';
            $res = lg_capture(['name' => 'Test lead (' . (MM_PROVIDERS[$p]['name'] ?? $p) . ')', 'email' => 'test+' . $p . time() . '@example.com',
                               'source' => $src, 'message' => 'Created by the assistant to test the connection. Safe to delete.'], null, 'assistant test', $uid);
            $cards[] = ['kind' => 'lead', 'label' => 'Open test lead', 'id' => $res['id']];
            return [['lead_id' => $res['id'], 'score' => $res['score'], 'grade' => $res['grade']], $cards];

        case 'search_leads':
            $f = lg_filters_from(['q' => (string) ($in['q'] ?? ''), 'grades' => !empty($in['grade']) ? [$in['grade']] : [],
                                  'statuses' => !empty($in['status']) ? [$in['status']] : []]);
            $rows = lg_segment_leads($f, 200);
            if (!empty($in['source'])) {
                $rows = array_values(array_filter($rows, fn($r) => strcasecmp((string) $r['source'], (string) $in['source']) === 0));
            }
            return [['count' => count($rows), 'leads' => array_map('mm_lead_brief', array_slice($rows, 0, 20))], []];

        case 'get_analytics':
            $days = (int) ($in['days'] ?? 30);
            $a = lg_analytics(in_array($days, [30, 90, 365, 0], true) ? $days : 30, $uid);
            unset($a['forms'], $a['trend']);
            return [$a, []];

        case 'create_campaign':
            $cname = trim((string) ($in['name'] ?? ''));
            if ($cname === '') return [['error' => 'name required'], []];
            $channel = in_array($in['channel'] ?? '', ['Email', 'WhatsApp', 'LinkedIn', 'Phone', 'Event', 'Ads'], true) ? $in['channel'] : 'Ads';
            $code = lg_slug($cname);
            execute_query("INSERT INTO campaigns (name, channel, status, budget, spent, utm_code, owner_user_id, created_at, updated_at)
                           VALUES (:n, :c, 'active', :b, :s, :utm, :u, NOW(), NOW())",
                [':n' => mb_substr($cname, 0, 190), ':c' => $channel, ':b' => max(0, (float) ($in['budget'] ?? 0)), ':s' => max(0, (float) ($in['spent'] ?? 0)), ':utm' => $code, ':u' => $uid]);
            return [['campaign_id' => (int) db()->lastInsertId(), 'utm_campaign' => $code, 'tip' => 'Add utm_campaign=' . $code . ' to links for this campaign.'], [['kind' => 'nav', 'label' => 'Open campaigns', 'path' => '/campaigns']]];

        case 'create_task':
            $title = trim((string) ($in['title'] ?? ''));
            if ($title === '') return [['error' => 'title required'], []];
            $leadId = (int) ($in['lead_id'] ?? 0);
            if ($leadId > 0 && lg_owned('leads', $leadId) === null) return [['error' => 'lead not found'], []];
            $due = preg_match('/^\d{4}-\d{2}-\d{2}$/', (string) ($in['due_date'] ?? '')) ? $in['due_date'] : null;
            $prio = in_array($in['priority'] ?? '', ['low', 'medium', 'high'], true) ? $in['priority'] : 'medium';
            execute_query("INSERT INTO tasks (related_type, related_id, title, due_date, status, priority, assigned_user_id, created_by, created_at, updated_at)
                           VALUES ('lead', :r, :t, :d, 'pending', :p, :u, :u2, NOW(), NOW())",
                [':r' => $leadId ?: null, ':t' => mb_substr($title, 0, 190), ':d' => $due, ':p' => $prio, ':u' => $uid, ':u2' => $uid]);
            if ($leadId) lg_log($leadId, 'task', 'Task added by assistant: ' . $title);
            return [['task_id' => (int) db()->lastInsertId()], [['kind' => 'nav', 'label' => 'Open tasks', 'path' => '/tasks']]];

        case 'update_lead_status':
            $id = (int) ($in['lead_id'] ?? 0);
            $status = (string) ($in['status'] ?? '');
            $lead = lg_owned('leads', $id);
            if ($lead === null) return [['error' => 'lead not found'], []];
            if ($lead['status'] === 'Converted') return [['error' => 'lead already converted'], []];
            if (!in_array($status, ['New', 'Contacted', 'Qualified', 'Unqualified'], true)) return [['error' => 'bad status'], []];
            execute_query('UPDATE leads SET status = :s, updated_at = NOW() WHERE id = :id', [':s' => $status, ':id' => $id]);
            lg_log($id, 'status', 'Status ' . $lead['status'] . ' → ' . $status . ' (assistant)');
            lg_rescore($id);
            return [['ok' => true], [['kind' => 'lead', 'label' => $lead['name'], 'id' => $id]]];

        case 'whatsapp_links':
            $msg = (string) ($in['message'] ?? '');
            $made = 0;
            foreach (array_slice((array) ($in['lead_ids'] ?? []), 0, 25) as $lid) {
                $l = lg_owned('leads', (int) $lid);
                if ($l === null || trim((string) $l['phone']) === '') continue;
                $first = preg_split('/\s+/', trim(preg_replace('/^(dr|mr|mrs|ms)\.?\s+/i', '', (string) $l['name'])))[0] ?? '';
                $digits = preg_replace('/\D/', '', (string) $l['phone']);
                if (strlen($digits) === 10) $digits = '91' . $digits;
                $cards[] = ['kind' => 'whatsapp', 'label' => 'Send to ' . $l['name'], 'url' => 'https://wa.me/' . $digits . '?text=' . rawurlencode(str_replace('{first_name}', $first, $msg)), 'id' => (int) $l['id']];
                $made++;
            }
            return [['buttons_created' => $made, 'skipped_without_phone' => count((array) ($in['lead_ids'] ?? [])) - $made], $cards];
    }
    return [['error' => 'unknown tool'], []];
}

// ── Claude call + agent loop ─────────────────────────────
function mm_ai_config(): ?array
{
    $file = __DIR__ . '/../config/ai.php';
    if (!is_file($file)) return null;
    $c = require $file;
    return (is_array($c) && trim((string) ($c['api_key'] ?? '')) !== '' && !str_contains((string) $c['api_key'], 'replace_with')) ? $c : null;
}

function mm_claude(array $cfg, array $payload): array
{
    $url = rtrim((string) ($cfg['base_url'] ?? 'https://api.anthropic.com'), '/') . '/v1/messages';
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 60,
        CURLOPT_HTTPHEADER => ['content-type: application/json', 'anthropic-version: 2023-06-01', 'x-api-key: ' . $cfg['api_key']],
        CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
    ]);
    $raw = curl_exec($ch);
    $code = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    $err = curl_error($ch);
    curl_close($ch);
    $data = json_decode((string) $raw, true);
    if ($raw === false || !is_array($data)) {
        throw new RuntimeException('AI service unreachable: ' . $err);
    }
    if ($code >= 400) {
        throw new RuntimeException('AI service error ' . $code . ': ' . ($data['error']['message'] ?? 'unknown'));
    }
    return $data;
}

function mm_system_prompt(array $user): string
{
    return "You are the MarketMosaic assistant inside a lead-management CRM used by small Indian businesses. The user is {$user['name']}. Today is " . date('l j F Y') . ".\n"
        . "Your main job: get their lead sources connected (WhatsApp, Facebook and Instagram, Google Ads, website, LinkedIn, IndiaMART and other portals, Zapier) and help them act on leads.\n"
        . "How to work:\n"
        . "- Use tools to check facts and to do the work. Start connection requests with get_integration_status or get_setup_guide.\n"
        . "- When the user wants to connect something, do the parts you can (create the key, link or embed code, send a test lead) and give only the steps they must do themselves in the other app, numbered and short.\n"
        . "- Never invent URLs, keys, numbers or features. Keys and links appear to the user as copy buttons under your reply; refer to them as 'the buttons below' and never paste a key in text.\n"
        . "- Be honest about what is native (Google Ads webhook, website forms, WhatsApp click-to-chat, tracked links) versus via Zapier (Facebook/Instagram lead ads, LinkedIn, portals) versus coming soon (WhatsApp Business API auto-replies, sending conversions back to ad platforms, Razorpay, Tally).\n"
        . "- Before changing more than one record, or anything the user did not ask for, ask first. Creating one key, link, task, campaign or test lead on request is fine.\n"
        . "- Keep replies short and practical: plain sentences, short numbered steps, no tables, no markdown headings. Use Indian rupees (₹) and Indian context. Reply in the user's language.";
}

/** @param array<int,array{role:string,content:string}> $history */
function mm_assistant(array $history, array $user): array
{
    $cfg = mm_ai_config();
    if ($cfg === null) {
        return ['reply' => "The AI assistant isn't switched on yet. Your admin needs to add a Claude API key in config/ai.php on the server (see config/ai.example.php). Meanwhile, every integration can be set up from the Connect tab.", 'cards' => [['kind' => 'nav', 'label' => 'Open Connect', 'path' => '/connect']], 'configured' => false];
    }
    $messages = [];
    foreach (array_slice($history, -16) as $m) {
        $role = ($m['role'] ?? '') === 'assistant' ? 'assistant' : 'user';
        $text = trim(mb_substr((string) ($m['content'] ?? ''), 0, 4000));
        if ($text === '') continue;
        if ($messages && end($messages)['role'] === $role) {
            $messages[count($messages) - 1]['content'] .= "\n\n" . $text;
        } else {
            $messages[] = ['role' => $role, 'content' => $text];
        }
    }
    while ($messages && $messages[0]['role'] !== 'user') array_shift($messages);
    if (!$messages || end($messages)['role'] !== 'user') {
        throw new InvalidArgumentException('Send a message.');
    }

    @set_time_limit(150);
    $cards = [];
    $actions = [];
    $tools = mm_tool_defs();
    for ($turn = 0; $turn < 6; $turn++) {
        $res = mm_claude($cfg, [
            'model' => $cfg['model'] ?? 'claude-sonnet-5-5',
            'max_tokens' => (int) ($cfg['max_tokens'] ?? 2048),
            'system' => mm_system_prompt($user),
            'tools' => $tools,
            'messages' => $messages,
        ]);
        $content = $res['content'] ?? [];
        $messages[] = ['role' => 'assistant', 'content' => $content];
        $uses = array_values(array_filter($content, fn($b) => ($b['type'] ?? '') === 'tool_use'));
        if (($res['stop_reason'] ?? '') !== 'tool_use' || !$uses) {
            $text = trim(implode("\n\n", array_map(fn($b) => (string) $b['text'], array_filter($content, fn($b) => ($b['type'] ?? '') === 'text'))));
            return ['reply' => $text !== '' ? $text : 'Done.', 'cards' => $cards, 'actions' => $actions, 'configured' => true];
        }
        $results = [];
        foreach ($uses as $u) {
            try {
                [$out, $c] = mm_run_tool((string) $u['name'], (array) ($u['input'] ?? []), $user);
                $cards = array_merge($cards, $c);
                $actions[] = $u['name'];
                $results[] = ['type' => 'tool_result', 'tool_use_id' => $u['id'], 'content' => json_encode($out, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)];
            } catch (Throwable $e) {
                $results[] = ['type' => 'tool_result', 'tool_use_id' => $u['id'], 'content' => 'Error: ' . $e->getMessage(), 'is_error' => true];
            }
        }
        $messages[] = ['role' => 'user', 'content' => $results];
    }
    return ['reply' => 'I did several steps but need you to confirm before going further. What would you like next?', 'cards' => $cards, 'actions' => $actions, 'configured' => true];
}
