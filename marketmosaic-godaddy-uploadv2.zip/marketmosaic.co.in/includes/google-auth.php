<?php

declare(strict_types=1);

function google_config(string $key, mixed $default = null): mixed
{
    global $googleConfig;

    return $googleConfig[$key] ?? $default;
}

function google_auth_is_configured(): bool
{
    return !str_contains((string) google_config('client_id', ''), 'replace_with_')
        && !str_contains((string) google_config('client_secret', ''), 'replace_with_');
}

function absolute_url(string $path): string
{
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = (string) ($_SERVER['HTTP_HOST'] ?? 'localhost');

    return $scheme . '://' . $host . base_url($path);
}

function google_redirect_uri(): string
{
    // An explicit URI in config/google.php always wins.
    $configured = trim((string) google_config('redirect_uri', ''));
    if ($configured !== '') {
        return $configured;
    }

    $path = base_url((string) google_config('redirect_path', 'google-callback.php'));
    $host = strtolower((string) ($_SERVER['HTTP_HOST'] ?? 'localhost'));

    // Local development: keep whatever host/scheme the browser used.
    if (str_starts_with($host, 'localhost') || str_starts_with($host, '127.0.0.1')) {
        return absolute_url((string) google_config('redirect_path', 'google-callback.php'));
    }

    // Live site: always https and no "www." so it matches the single URI
    // registered in Google Cloud Console, however the visitor typed the address.
    return 'https://' . preg_replace('/^www\./', '', $host) . $path;
}

function google_authorization_url(string $state): string
{
    return 'https://accounts.google.com/o/oauth2/v2/auth?' . http_build_query([
        'client_id' => (string) google_config('client_id'),
        'redirect_uri' => google_redirect_uri(),
        'response_type' => 'code',
        'scope' => 'openid email profile',
        'state' => $state,
        'access_type' => 'online',
        'prompt' => 'select_account',
    ]);
}

function http_post_form(string $url, array $fields): array
{
    if (function_exists('curl_init')) {
        $curl = curl_init($url);
        curl_setopt_array($curl, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => http_build_query($fields),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded'],
            CURLOPT_TIMEOUT => 20,
        ]);

        $response = curl_exec($curl);
        $status = (int) curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
        curl_close($curl);
    } else {
        $context = stream_context_create([
            'http' => [
                'method' => 'POST',
                'header' => "Content-Type: application/x-www-form-urlencoded\r\n",
                'content' => http_build_query($fields),
                'timeout' => 20,
            ],
        ]);

        $response = file_get_contents($url, false, $context);
        $status = 200;
    }

    $payload = json_decode((string) $response, true);

    if (!is_array($payload) || $status >= 400) {
        throw new RuntimeException('Google token request failed.');
    }

    return $payload;
}

function http_get_json(string $url, string $accessToken): array
{
    if (function_exists('curl_init')) {
        $curl = curl_init($url);
        curl_setopt_array($curl, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $accessToken],
            CURLOPT_TIMEOUT => 20,
        ]);

        $response = curl_exec($curl);
        $status = (int) curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
        curl_close($curl);
    } else {
        $context = stream_context_create([
            'http' => [
                'method' => 'GET',
                'header' => 'Authorization: Bearer ' . $accessToken . "\r\n",
                'timeout' => 20,
            ],
        ]);

        $response = file_get_contents($url, false, $context);
        $status = 200;
    }

    $payload = json_decode((string) $response, true);

    if (!is_array($payload) || $status >= 400) {
        throw new RuntimeException('Google user profile request failed.');
    }

    return $payload;
}
