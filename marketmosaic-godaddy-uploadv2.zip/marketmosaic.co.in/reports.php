<?php

declare(strict_types=1);

require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/layout.php';

require_auth();

$userId = session_user_id();
$summary = ['total_leads' => 0, 'new_leads' => 0, 'qualified_leads' => 0, 'active_campaigns' => 0, 'campaign_responses' => 0, 'campaign_conversions' => 0, 'campaign_budget' => 0];
$sourcePerformance = [];
$leadPipeline = [];
$campaignPerformance = [];
$monthlyLeads = [];

try {
    $summary = array_merge($summary, fetch_one(
        "SELECT
            (SELECT COUNT(*) FROM leads WHERE owner_user_id = :leads_user) AS total_leads,
            (SELECT COUNT(*) FROM leads WHERE owner_user_id = :new_user AND created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)) AS new_leads,
            (SELECT COUNT(*) FROM leads WHERE owner_user_id = :qualified_user AND status = 'Qualified') AS qualified_leads,
            (SELECT COUNT(*) FROM campaigns WHERE owner_user_id = :campaign_user AND status = 'active') AS active_campaigns,
            (SELECT COUNT(*) FROM campaign_leads cl INNER JOIN campaigns c ON c.id = cl.campaign_id WHERE c.owner_user_id = :response_user AND cl.member_status = 'responded') AS campaign_responses,
            (SELECT COUNT(*) FROM campaign_leads cl INNER JOIN campaigns c ON c.id = cl.campaign_id WHERE c.owner_user_id = :converted_user AND cl.member_status = 'converted') AS campaign_conversions,
            (SELECT COALESCE(SUM(budget), 0) FROM campaigns WHERE owner_user_id = :budget_user) AS campaign_budget",
        [':leads_user' => $userId, ':new_user' => $userId, ':qualified_user' => $userId, ':campaign_user' => $userId, ':response_user' => $userId, ':converted_user' => $userId, ':budget_user' => $userId]
    ) ?? []);

    $sourcePerformance = fetch_all(
        "SELECT COALESCE(NULLIF(source, ''), 'Unspecified') AS source, COUNT(*) AS total,
                SUM(status = 'Qualified') AS qualified, SUM(status = 'New') AS new_leads
         FROM leads WHERE owner_user_id = :user_id
         GROUP BY COALESCE(NULLIF(source, ''), 'Unspecified')
         ORDER BY total DESC, source ASC LIMIT 10",
        [':user_id' => $userId]
    );
    $leadPipeline = fetch_all(
        'SELECT status, COUNT(*) AS total FROM leads WHERE owner_user_id = :user_id GROUP BY status ORDER BY total DESC, status ASC',
        [':user_id' => $userId]
    );
    $campaignPerformance = fetch_all(
        "SELECT c.id, c.name, c.channel, c.status, c.budget,
                COUNT(cl.id) AS targeted,
                COALESCE(SUM(cl.member_status IN ('sent', 'responded', 'converted')), 0) AS sent,
                COALESCE(SUM(cl.member_status IN ('responded', 'converted')), 0) AS responses,
                COALESCE(SUM(cl.member_status = 'converted'), 0) AS converted
         FROM campaigns c
         LEFT JOIN campaign_leads cl ON cl.campaign_id = c.id
         WHERE c.owner_user_id = :user_id
         GROUP BY c.id, c.name, c.channel, c.status, c.budget
         ORDER BY c.created_at DESC LIMIT 12",
        [':user_id' => $userId]
    );
    $monthlyLeads = fetch_all(
        "SELECT DATE_FORMAT(created_at, '%Y-%m') AS month, COUNT(*) AS total
         FROM leads WHERE owner_user_id = :user_id AND created_at >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
         GROUP BY DATE_FORMAT(created_at, '%Y-%m') ORDER BY month ASC",
        [':user_id' => $userId]
    );
} catch (Throwable $exception) {
    flash('error', 'Analytics could not load. Check your database connection and schema.');
}

$maxSource = max([1, ...array_map(static fn (array $row): int => (int) $row['total'], $sourcePerformance)]);
$maxMonthly = max([1, ...array_map(static fn (array $row): int => (int) $row['total'], $monthlyLeads)]);
$responseRate = (int) $summary['campaign_conversions'] + (int) $summary['campaign_responses'];
$responseRate = $responseRate > 0 ? (int) round(100 * (int) $summary['campaign_conversions'] / $responseRate) : 0;

render_layout_start('Analytics', 'Marketing Analytics', 'Track lead quality, acquisition sources, and campaign outcomes across your pipeline.');
?>

<section class="lg-wrap" style="padding-bottom:0">
  <div class="card lg-actions" style="justify-content:space-between">
    <span><strong>Need cost per lead, ROI and the full funnel?</strong> <span class="muted">Lead scores, campaign spend and won deals are combined on the Funnel &amp; ROI page.</span></span>
    <a class="primary-button" href="<?= e(base_url('analytics.php')) ?>">Open Funnel &amp; ROI</a>
  </div>
</section>
<section class="grid grid-4">
  <article class="card"><p class="muted">Total Leads</p><p class="stat-number"><?= e((string) $summary['total_leads']) ?></p><small class="muted"><?= e((string) $summary['new_leads']) ?> added in the last 30 days</small></article>
  <article class="card"><p class="muted">Qualified Leads</p><p class="stat-number"><?= e((string) $summary['qualified_leads']) ?></p><small class="muted">Based on current lead status</small></article>
  <article class="card"><p class="muted">Active Campaigns</p><p class="stat-number"><?= e((string) $summary['active_campaigns']) ?></p><small class="muted">INR <?= e(number_format((float) $summary['campaign_budget'], 0)) ?> total planned budget</small></article>
  <article class="card"><p class="muted">Campaign Conversions</p><p class="stat-number"><?= e((string) $summary['campaign_conversions']) ?></p><small class="muted"><?= e((string) $summary['campaign_responses']) ?> responses · <?= e((string) $responseRate) ?>% of responses converted</small></article>
</section>

<section class="split analytics-layout" style="margin-top:1.25rem;">
  <article class="card">
    <h2 style="margin-top:0;">Lead acquisition by source</h2>
    <?php if ($sourcePerformance === []): ?><p class="muted">Lead source analytics will appear when leads are added.</p><?php else: ?>
      <div class="analytics-bars">
        <?php foreach ($sourcePerformance as $row): $width = max(4, (int) round(100 * (int) $row['total'] / $maxSource)); ?>
          <div class="analytics-row"><div class="analytics-label"><span><?= e((string) $row['source']) ?></span><strong><?= e((string) $row['total']) ?></strong></div><div class="analytics-track"><span style="width:<?= e((string) $width) ?>%"></span></div><small class="muted"><?= e((string) $row['qualified']) ?> qualified · <?= e((string) $row['new_leads']) ?> new</small></div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </article>
  <article class="card">
    <h2 style="margin-top:0;">Lead status</h2>
    <?php if ($leadPipeline === []): ?><p class="muted">No lead statuses to show yet.</p><?php else: ?>
      <div class="table-wrap"><table><thead><tr><th>Status</th><th>Leads</th><th>Share</th></tr></thead><tbody>
        <?php foreach ($leadPipeline as $row): $share = (int) $summary['total_leads'] > 0 ? (int) round(100 * (int) $row['total'] / (int) $summary['total_leads']) : 0; ?>
          <tr><td><span class="tag"><?= e((string) $row['status']) ?></span></td><td><?= e((string) $row['total']) ?></td><td><?= e((string) $share) ?>%</td></tr>
        <?php endforeach; ?>
      </tbody></table></div>
    <?php endif; ?>
  </article>
</section>

<section class="split analytics-layout" style="margin-top:1.25rem;">
  <article class="card">
    <h2 style="margin-top:0;">New leads over time</h2>
    <?php if ($monthlyLeads === []): ?><p class="muted">Monthly lead activity will appear here.</p><?php else: ?>
      <div class="analytics-bars analytics-monthly">
        <?php foreach ($monthlyLeads as $row): $width = max(4, (int) round(100 * (int) $row['total'] / $maxMonthly)); ?>
          <div class="analytics-row"><div class="analytics-label"><span><?= e(date('M Y', strtotime((string) $row['month'] . '-01'))) ?></span><strong><?= e((string) $row['total']) ?></strong></div><div class="analytics-track"><span style="width:<?= e((string) $width) ?>%"></span></div></div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </article>
  <article class="card">
    <div class="inline-actions" style="justify-content:space-between;"><h2 style="margin:0;">Campaign performance</h2><a class="ghost-button" href="<?= e(base_url('campaigns.php')) ?>">Manage campaigns</a></div>
    <?php if ($campaignPerformance === []): ?><p class="muted" style="margin-top:1rem;">Create a campaign and add leads to start tracking outcomes.</p><?php else: ?>
      <div class="table-wrap" style="margin-top:1rem;"><table><thead><tr><th>Campaign</th><th>Channel</th><th>Targeted</th><th>Responded</th><th>Converted</th></tr></thead><tbody>
        <?php foreach ($campaignPerformance as $campaign): ?>
          <tr><td><strong><?= e((string) $campaign['name']) ?></strong><div class="muted"><?= e(ucfirst((string) $campaign['status'])) ?></div></td><td><?= e((string) $campaign['channel']) ?></td><td><?= e((string) $campaign['targeted']) ?></td><td><?= e((string) $campaign['responses']) ?></td><td><?= e((string) $campaign['converted']) ?></td></tr>
        <?php endforeach; ?>
      </tbody></table></div>
    <?php endif; ?>
  </article>
</section>

<?php render_layout_end(); ?>
