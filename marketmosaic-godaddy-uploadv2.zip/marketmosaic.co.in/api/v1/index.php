<?php
/**
 * MarketMosaic JSON API — used by the Android / iOS / web app and by integrations
 * (Zapier, Facebook & Google lead ads, your own website).
 *
 *   Base URL:  https://marketmosaic.co.in/api/v1/?r=<route>      (v1 — breaking changes will go to /api/v2/)
 *   Auth:      header  X-Api-Key: mm_xxx   (or Authorization: Bearer mm_xxx)
 *              get a key from POST ?r=login, or create one under "API & mobile app"
 *
 * Every route only sees records owned by the user the key belongs to.
 *
 * Routes
 *   POST login            {email, password, device?}        -> {token, user}
 *   POST logout                                            -> revokes the key used
 *   GET  me
 *   GET  dashboard                                         -> KPIs, hot leads, due tasks
 *   GET  leads            ?q= &grade= &status= &limit=
 *   GET  lead             ?id=                             -> lead, score breakdown, timeline
 *   POST leads            {name, email, phone?, company?, source?, message?, utm_*}  (dedupes by email)
 *   POST lead_status      {id, status}
 *   POST lead_note        {id, note}
 *   POST lead_convert     {id, deal_title?, deal_value?}
 *   GET  analytics        ?days=30|90|365|0
 *   GET  campaigns
 *   GET  forms                                             -> share links for capture forms
 *
 * Added for the MarketMosaic app (Nov 2026)
 *   POST signup           {name, email, password, device?}  -> {token, user}
 *   GET  leads            also ?since=YYYY-MM-DD HH:MM:SS   (new-lead alerts) and ?source=
 *   POST lead_update      {id, name?, email?, phone?, company?}
 *   GET  tasks            ?status=open|done|all
 *   POST task_create      {title, due_date?, priority?, lead_id?, description?}
 *   POST task_done        {id, done}
 *   GET  deals                                             -> {stages, deals, totals}
 *   POST deal_create      {title, value?, stage_id?, expected_close_date?}
 *   POST deal_update      {id, stage_id?, status? (open|won|lost), value?, title?}
 *   POST campaign_create  {name, channel, budget?, spent?}
 *   POST api_key_create   {name}                            -> {token}  (for Zapier / Google Ads webhooks)
 *   POST google_lead      Google Ads lead-form webhook. Webhook URL = this route, "Key" = an API key.
 *   GET  integrations                                      -> status of each lead source
 *   POST assistant        {messages:[{role, content}]}     -> {reply, cards}  AI assistant (config/ai.php)
 *   POST integration_action {tool, input}                  -> {result, cards} (key, tracked link, embed code, test lead)
 */

declare(strict_types=1);

require __DIR__ . '/../../includes/bootstrap.php';
require_once __DIR__ . '/../../includes/assistant.php';

if (session_status() === PHP_SESSION_ACTIVE) {
    session_write_close(); // the API is stateless; nothing below is stored in the session
}

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Api-Key');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Cache-Control: no-store');
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
    http_response_code(204);
    exit;
}

function api_out(mixed $data, int $code = 200): never
{
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function api_fail(string $message, int $code = 400): never
{
    api_out(['error' => $message], $code);
}

function api_input(): array
{
    static $in = null;
    if ($in === null) {
        $raw = (string) file_get_contents('php://input');
        $json = json_decode($raw, true);
        $in = is_array($json) ? $json : $_POST;
    }
    return $in;
}

function api_token(): string
{
    $h = (string) ($_SERVER['HTTP_X_API_KEY'] ?? '');
    if ($h === '') {
        $auth = (string) ($_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
        if (stripos($auth, 'Bearer ') === 0) {
            $h = trim(substr($auth, 7));
        }
    }
    return $h;
}

function api_lead_out(array $l): array
{
    return [
        'id' => (int) $l['id'], 'name' => $l['name'], 'email' => $l['email'], 'phone' => $l['phone'],
        'company' => $l['company_name'], 'source' => $l['source'], 'status' => $l['status'],
        'score' => (int) $l['score'], 'grade' => $l['grade'], 'campaign_id' => $l['campaign_id'] ? (int) $l['campaign_id'] : null,
        'utm_source' => $l['utm_source'] ?? null, 'utm_medium' => $l['utm_medium'] ?? null, 'utm_campaign' => $l['utm_campaign'] ?? null,
        'notes' => $l['notes_summary'], 'created_at' => $l['created_at'], 'last_activity_at' => $l['last_activity_at'] ?? null,
    ];
}

$route = preg_replace('/[^a-z_]/', '', strtolower((string) ($_GET['r'] ?? '')));
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

try {
    if (!is_database_configured()) {
        api_fail('Database is not configured.', 503);
    }

    // ── public: login ──
    if ($route === 'login') {
        if ($method !== 'POST') api_fail('Use POST.', 405);
        $in = api_input();
        $user = fetch_one("SELECT * FROM users WHERE email = :e AND status = 'active' LIMIT 1", [':e' => strtolower(trim((string) ($in['email'] ?? '')))]);
        if ($user === null || !password_verify((string) ($in['password'] ?? ''), (string) $user['password_hash'])) {
            usleep(400000);
            api_fail('Email or password is incorrect.', 401);
        }
        $token = lg_create_token((int) $user['id'], 'App: ' . mb_substr((string) ($in['device'] ?? 'mobile'), 0, 60));
        api_out(['token' => $token, 'user' => ['id' => (int) $user['id'], 'name' => $user['name'], 'email' => $user['email'], 'role' => $user['role']]]);
    }

    // ── public: Google Ads lead form webhook ──
    // In Google Ads → Lead form → Lead delivery → Webhook: URL = https://<site>/api/v1/?r=google_lead, Key = an API key.
    if ($route === 'google_lead') {
        if ($method !== 'POST') api_fail('Use POST.', 405);
        $in = api_input();
        $owner = lg_user_for_token((string) ($in['google_key'] ?? ''));
        if ($owner === null) api_fail('Invalid google_key.', 401);
        $cols = [];
        foreach ((array) ($in['user_column_data'] ?? []) as $c) {
            $id = strtoupper((string) ($c['column_id'] ?? $c['column_name'] ?? ''));
            $cols[$id] = trim((string) ($c['string_value'] ?? ''));
        }
        $name = $cols['FULL_NAME'] ?? trim(($cols['FIRST_NAME'] ?? '') . ' ' . ($cols['LAST_NAME'] ?? ''));
        $extra = [];
        foreach ($cols as $k => $v) {
            if (!in_array($k, ['FULL_NAME', 'FIRST_NAME', 'LAST_NAME', 'EMAIL', 'WORK_EMAIL', 'PHONE_NUMBER', 'WORK_PHONE', 'COMPANY_NAME'], true) && $v !== '') {
                $extra[] = ucwords(strtolower(str_replace('_', ' ', $k))) . ': ' . $v;
            }
        }
        if (!empty($in['is_test'])) {
            $extra[] = '(Google Ads test lead)';
        }
        $res = lg_capture([
            'name' => $name,
            'email' => $cols['EMAIL'] ?? $cols['WORK_EMAIL'] ?? '',
            'phone' => $cols['PHONE_NUMBER'] ?? $cols['WORK_PHONE'] ?? '',
            'company' => $cols['COMPANY_NAME'] ?? '',
            'source' => 'Google',
            'utm_source' => 'google',
            'utm_medium' => 'lead_form',
            'utm_campaign' => (string) ($in['campaign_name'] ?? $in['campaign_id'] ?? ''),
            'message' => implode('; ', $extra),
        ], null, 'Google Ads lead form', (int) $owner['id']);
        api_out(['ok' => true, 'lead_id' => $res['id']]);
    }

    // ── public: sign up (same rules as signup.php) ──
    if ($route === 'signup') {
        if ($method !== 'POST') api_fail('Use POST.', 405);
        $in = api_input();
        $name = trim((string) ($in['name'] ?? ''));
        $email = strtolower(trim((string) ($in['email'] ?? '')));
        $password = (string) ($in['password'] ?? '');
        if ($name === '') api_fail('Enter your name.', 422);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) api_fail('Enter a valid email.', 422);
        if (strlen($password) < 8) api_fail('Password must be at least 8 characters.', 422);
        if (fetch_one('SELECT id FROM users WHERE email = :e LIMIT 1', [':e' => $email]) !== null) {
            api_fail('An account already exists for this email. Sign in instead.', 409);
        }
        // The very first account on a fresh install becomes the admin.
        $isFirst = fetch_one('SELECT id FROM users LIMIT 1') === null;
        execute_query("INSERT INTO users (name, email, password_hash, role, status, created_at, updated_at)
                       VALUES (:n, :e, :h, :r, 'active', NOW(), NOW())",
            [':n' => mb_substr($name, 0, 120), ':e' => $email, ':h' => password_hash($password, PASSWORD_DEFAULT), ':r' => $isFirst ? 'admin' : 'sales']);
        $uid = (int) db()->lastInsertId();
        $token = lg_create_token($uid, 'App: ' . mb_substr((string) ($in['device'] ?? 'mobile'), 0, 60));
        api_out(['token' => $token, 'user' => ['id' => $uid, 'name' => $name, 'email' => $email, 'role' => $isFirst ? 'admin' : 'sales']], 201);
    }

    $user = lg_user_for_token(api_token());
    if ($user === null) {
        api_fail('Unauthorized — send your key in the X-Api-Key header.', 401);
    }
    $_SESSION[app_config('session_key', 'marketmosaic_crm_user_id')] = (int) $user['id']; // attribute timeline entries to this user (not persisted)

    switch ($route) {
        case 'logout':
            execute_query('DELETE FROM api_tokens WHERE id = :id', [':id' => $user['token_id']]);
            api_out(['ok' => true]);

        case 'me':
            api_out(['id' => (int) $user['id'], 'name' => $user['name'], 'email' => $user['email'], 'role' => $user['role']]);

        case 'dashboard':
            lg_run_due(20);
            $a = lg_analytics(30);
            $hot = fetch_all("SELECT * FROM leads WHERE owner_user_id = :u AND grade = 'hot' AND status IN ('New','Contacted','Qualified') ORDER BY score DESC, created_at DESC LIMIT 5", [':u' => $user['id']]);
            $tasks = fetch_all("SELECT id, title, due_date, status, priority FROM tasks WHERE assigned_user_id = :u AND status <> 'completed' ORDER BY due_date IS NULL, due_date LIMIT 5", [':u' => $user['id']]);
            api_out(['kpis' => $a['kpis'], 'funnel' => $a['funnel'], 'grades' => $a['grades'],
                     'hot_leads' => array_map('api_lead_out', $hot), 'tasks' => $tasks]);

        case 'leads':
            if ($method === 'POST') {
                $res = lg_capture(api_input(), null, 'api');
                $lead = fetch_one('SELECT * FROM leads WHERE id = :id', [':id' => $res['id']]);
                api_out(['lead' => api_lead_out($lead), 'created' => $res['created']], $res['created'] ? 201 : 200);
            }
            $f = lg_filters_from([
                'q' => $_GET['q'] ?? '',
                'grades' => ($_GET['grade'] ?? '') !== '' ? [$_GET['grade']] : [],
                'statuses' => ($_GET['status'] ?? '') !== '' ? [$_GET['status']] : [],
            ]);
            $rows = lg_segment_leads($f, bounded_int($_GET['limit'] ?? 100, 1, 500));
            $since = trim((string) ($_GET['since'] ?? ''));
            if ($since !== '') {
                $rows = array_values(array_filter($rows, fn($r) => (string) $r['created_at'] > $since));
            }
            $source = trim((string) ($_GET['source'] ?? ''));
            if ($source !== '') {
                $rows = array_values(array_filter($rows, fn($r) => strcasecmp((string) $r['source'], $source) === 0));
            }
            api_out(['leads' => array_map('api_lead_out', $rows), 'server_time' => date('Y-m-d H:i:s')]);

        case 'lead':
            $id = (int) ($_GET['id'] ?? 0);
            if (lg_owned('leads', $id) === null) api_fail('Lead not found.', 404);
            $res = lg_rescore($id);
            [$score, $parts] = $res;
            $lead = fetch_one('SELECT l.*, c.name AS campaign_name FROM leads l LEFT JOIN campaigns c ON c.id = l.campaign_id WHERE l.id = :id', [':id' => $id]);
            $events = fetch_all('SELECT event_type AS type, detail, created_at FROM lead_events WHERE lead_id = :id ORDER BY created_at DESC, id DESC LIMIT 100', [':id' => $id]);
            api_out(['lead' => api_lead_out($lead) + ['campaign_name' => $lead['campaign_name']],
                     'score_breakdown' => array_map(fn($p) => ['label' => $p[0], 'points' => $p[1]], $parts),
                     'timeline' => $events]);

        case 'lead_status':
            $in = api_input();
            $id = (int) ($in['id'] ?? 0);
            $status = (string) ($in['status'] ?? '');
            if (!in_array($status, ['New', 'Contacted', 'Qualified', 'Unqualified'], true)) api_fail('Status must be New, Contacted, Qualified or Unqualified.');
            $lead = lg_owned('leads', $id);
            if ($lead === null) api_fail('Lead not found.', 404);
            if ($lead['status'] === 'Converted') api_fail('Converted leads cannot change status.', 409);
            if ($lead['status'] !== $status) {
                execute_query('UPDATE leads SET status = :s, updated_at = NOW() WHERE id = :id', [':s' => $status, ':id' => $id]);
                lg_log($id, 'status', 'Status ' . $lead['status'] . ' → ' . $status . ' (app)');
            }
            lg_rescore($id);
            api_out(['lead' => api_lead_out(fetch_one('SELECT * FROM leads WHERE id = :id', [':id' => $id]))]);

        case 'lead_note':
            $in = api_input();
            $id = (int) ($in['id'] ?? 0);
            $note = trim((string) ($in['note'] ?? ''));
            if ($note === '') api_fail('Note is empty.');
            if (lg_owned('leads', $id) === null) api_fail('Lead not found.', 404);
            lg_log($id, 'note', $note);
            api_out(['ok' => true]);

        case 'lead_convert':
            $in = api_input();
            if (lg_owned('leads', (int) ($in['id'] ?? 0)) === null) api_fail('Lead not found.', 404);
            $contactId = lg_convert((int) ($in['id'] ?? 0), trim((string) ($in['deal_title'] ?? '')), (float) ($in['deal_value'] ?? 0));
            api_out(['contact_id' => $contactId, 'lead' => api_lead_out(fetch_one('SELECT * FROM leads WHERE id = :id', [':id' => (int) $in['id']]))]);

        case 'analytics':
            $days = (int) ($_GET['days'] ?? 90);
            api_out(lg_analytics(in_array($days, [30, 90, 365, 0], true) ? $days : 90));

        case 'campaigns':
            api_out(['campaigns' => lg_analytics(0)['campaigns']]);

        case 'forms':
            $forms = fetch_all('SELECT id, name, public_key, heading, views, submissions, active FROM lead_forms WHERE created_by = :u ORDER BY created_at DESC', [':u' => $user['id']]);
            foreach ($forms as &$f) {
                $f['url'] = lg_public_url('f.php?k=' . $f['public_key']);
                unset($f['public_key']);
            }
            api_out(['forms' => $forms]);

        case 'lead_update':
            $in = api_input();
            $id = (int) ($in['id'] ?? 0);
            $lead = lg_owned('leads', $id);
            if ($lead === null) api_fail('Lead not found.', 404);
            $name = trim((string) ($in['name'] ?? $lead['name']));
            $email = strtolower(trim((string) ($in['email'] ?? $lead['email'])));
            if ($name === '') api_fail('Name cannot be empty.', 422);
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) api_fail('Enter a valid email.', 422);
            execute_query('UPDATE leads SET name = :n, email = :e, phone = :p, company_name = :c, updated_at = NOW() WHERE id = :id', [
                ':n' => mb_substr($name, 0, 190), ':e' => $email,
                ':p' => mb_substr(trim((string) ($in['phone'] ?? $lead['phone'] ?? '')), 0, 50),
                ':c' => mb_substr(trim((string) ($in['company'] ?? $lead['company_name'] ?? '')), 0, 190), ':id' => $id]);
            lg_log($id, 'note', 'Details edited (app)');
            lg_rescore($id);
            api_out(['lead' => api_lead_out(fetch_one('SELECT * FROM leads WHERE id = :id', [':id' => $id]))]);

        case 'tasks':
            $status = (string) ($_GET['status'] ?? 'open');
            $where = $status === 'done' ? "AND t.status = 'completed'" : ($status === 'all' ? '' : "AND t.status <> 'completed'");
            $rows = fetch_all("SELECT t.id, t.title, t.description, t.due_date, t.status, t.priority, t.related_type, t.related_id,
                                      l.name AS lead_name, l.phone AS lead_phone
                               FROM tasks t
                               LEFT JOIN leads l ON t.related_type = 'lead' AND l.id = t.related_id
                               WHERE t.assigned_user_id = :u $where
                               ORDER BY t.status = 'completed', t.due_date IS NULL, t.due_date, t.id DESC LIMIT 300", [':u' => $user['id']]);
            foreach ($rows as &$t) {
                $t['id'] = (int) $t['id'];
                $t['related_id'] = $t['related_id'] !== null ? (int) $t['related_id'] : null;
            }
            unset($t);
            api_out(['tasks' => $rows]);

        case 'task_create':
            $in = api_input();
            $title = trim((string) ($in['title'] ?? ''));
            if ($title === '') api_fail('Give the task a title.', 422);
            $leadId = (int) ($in['lead_id'] ?? 0);
            if ($leadId > 0 && lg_owned('leads', $leadId) === null) api_fail('Lead not found.', 404);
            $due = (string) ($in['due_date'] ?? '');
            $due = preg_match('/^\d{4}-\d{2}-\d{2}$/', $due) ? $due : null;
            $priority = in_array($in['priority'] ?? '', ['low', 'medium', 'high'], true) ? $in['priority'] : 'medium';
            execute_query("INSERT INTO tasks (related_type, related_id, title, description, due_date, status, priority, assigned_user_id, created_by, created_at, updated_at)
                           VALUES ('lead', :r, :t, :d, :due, 'pending', :p, :u, :u2, NOW(), NOW())",
                [':r' => $leadId ?: null, ':t' => mb_substr($title, 0, 190), ':d' => trim((string) ($in['description'] ?? '')) ?: null,
                 ':due' => $due, ':p' => $priority, ':u' => $user['id'], ':u2' => $user['id']]);
            $taskId = (int) db()->lastInsertId();
            if ($leadId > 0) {
                lg_log($leadId, 'task', 'Task added: ' . $title . ($due ? ' (due ' . $due . ')' : ''));
            }
            api_out(['id' => $taskId], 201);

        case 'task_done':
            $in = api_input();
            $id = (int) ($in['id'] ?? 0);
            $task = fetch_one('SELECT * FROM tasks WHERE id = :id AND assigned_user_id = :u', [':id' => $id, ':u' => $user['id']]);
            if ($task === null) api_fail('Task not found.', 404);
            $done = !empty($in['done']);
            execute_query('UPDATE tasks SET status = :s, updated_at = NOW() WHERE id = :id', [':s' => $done ? 'completed' : 'pending', ':id' => $id]);
            if ($done && $task['related_type'] === 'lead' && $task['related_id']) {
                lg_log((int) $task['related_id'], 'task', 'Task done: ' . $task['title']);
            }
            api_out(['ok' => true]);

        case 'deals':
            $stages = fetch_all('SELECT id, name, sort_order, win_probability FROM pipeline_stages ORDER BY sort_order, id');
            $rows = fetch_all("SELECT d.id, d.title, d.value, d.currency, d.stage_id, d.status, d.expected_close_date, d.updated_at,
                                      TRIM(CONCAT(COALESCE(ct.first_name, ''), ' ', COALESCE(ct.last_name, ''))) AS contact_name,
                                      ct.phone AS contact_phone, co.name AS company_name
                               FROM deals d
                               LEFT JOIN contacts ct ON ct.id = d.contact_id
                               LEFT JOIN companies co ON co.id = d.company_id
                               WHERE d.owner_user_id = :u ORDER BY d.updated_at DESC LIMIT 500", [':u' => $user['id']]);
            $totals = ['open' => 0.0, 'won' => 0.0, 'lost' => 0.0, 'weighted' => 0.0];
            $prob = array_column($stages, 'win_probability', 'id');
            foreach ($rows as &$d) {
                $d['id'] = (int) $d['id'];
                $d['value'] = (float) $d['value'];
                $d['stage_id'] = $d['stage_id'] !== null ? (int) $d['stage_id'] : null;
                $totals[$d['status']] += $d['value'];
                if ($d['status'] === 'open') {
                    $totals['weighted'] += $d['value'] * ((int) ($prob[$d['stage_id']] ?? 0)) / 100;
                }
            }
            unset($d);
            foreach ($stages as &$st) {
                $st['id'] = (int) $st['id'];
                $st['win_probability'] = (int) $st['win_probability'];
            }
            unset($st);
            api_out(['stages' => $stages, 'deals' => $rows, 'totals' => $totals]);

        case 'deal_create':
            $in = api_input();
            $title = trim((string) ($in['title'] ?? ''));
            if ($title === '') api_fail('Give the deal a title.', 422);
            $stageId = (int) ($in['stage_id'] ?? 0);
            if ($stageId <= 0 || fetch_one('SELECT id FROM pipeline_stages WHERE id = :id', [':id' => $stageId]) === null) {
                $stageId = (int) (fetch_one('SELECT id FROM pipeline_stages ORDER BY sort_order LIMIT 1')['id'] ?? 0);
            }
            $close = (string) ($in['expected_close_date'] ?? '');
            execute_query("INSERT INTO deals (title, value, currency, stage_id, status, expected_close_date, owner_user_id, created_at, updated_at)
                           VALUES (:t, :v, 'INR', :s, 'open', :c, :u, NOW(), NOW())",
                [':t' => mb_substr($title, 0, 190), ':v' => max(0, (float) ($in['value'] ?? 0)), ':s' => $stageId ?: null,
                 ':c' => preg_match('/^\d{4}-\d{2}-\d{2}$/', $close) ? $close : null, ':u' => $user['id']]);
            api_out(['id' => (int) db()->lastInsertId()], 201);

        case 'deal_update':
            $in = api_input();
            $id = (int) ($in['id'] ?? 0);
            $deal = fetch_one('SELECT * FROM deals WHERE id = :id AND owner_user_id = :u', [':id' => $id, ':u' => $user['id']]);
            if ($deal === null) api_fail('Deal not found.', 404);
            $stageId = isset($in['stage_id']) ? (int) $in['stage_id'] : (int) $deal['stage_id'];
            if (isset($in['stage_id']) && fetch_one('SELECT id FROM pipeline_stages WHERE id = :id', [':id' => $stageId]) === null) {
                api_fail('Unknown stage.', 422);
            }
            $status = in_array($in['status'] ?? '', ['open', 'won', 'lost'], true) ? $in['status'] : $deal['status'];
            execute_query('UPDATE deals SET stage_id = :s, status = :st, value = :v, title = :t, updated_at = NOW() WHERE id = :id', [
                ':s' => $stageId ?: null, ':st' => $status,
                ':v' => isset($in['value']) ? max(0, (float) $in['value']) : $deal['value'],
                ':t' => trim((string) ($in['title'] ?? '')) !== '' ? mb_substr(trim((string) $in['title']), 0, 190) : $deal['title'],
                ':id' => $id]);
            $lead = fetch_one('SELECT id FROM leads WHERE deal_id = :d LIMIT 1', [':d' => $id]);
            if ($lead && $status !== $deal['status']) {
                lg_log((int) $lead['id'], 'deal', 'Deal marked ' . $status . ' (app)');
                lg_rescore((int) $lead['id']);
            }
            api_out(['ok' => true]);

        case 'integrations':
            $providers = mm_provider_status((int) $user['id']);
            foreach ($providers as &$pr) {
                $pr['guide'] = MM_SETUP_GUIDES[$pr['key']] ?? '';
            }
            unset($pr);
            api_out(['providers' => $providers, 'assistant' => mm_ai_config() !== null]);

        case 'integration_action':
            // the Connect tab's buttons run the same tools as the assistant
            $in = api_input();
            $tool = (string) ($in['tool'] ?? '');
            if (!in_array($tool, ['create_connection_key', 'get_tracked_link', 'get_embed_code', 'send_test_lead'], true)) api_fail('Unknown action.', 422);
            [$out, $cards] = mm_run_tool($tool, (array) ($in['input'] ?? []), $user);
            api_out(['result' => $out, 'cards' => $cards]);

        case 'assistant':
            if ($method !== 'POST') api_fail('Use POST.', 405);
            try {
                api_out(mm_assistant((array) (api_input()['messages'] ?? []), $user));
            } catch (RuntimeException $e) {
                error_log('assistant: ' . $e->getMessage());
                api_fail('The assistant is unavailable right now. Please try again in a minute.', 502);
            }

        case 'api_key_create':
            $name = trim((string) (api_input()['name'] ?? 'Integration'));
            $token = lg_create_token((int) $user['id'], mb_substr($name !== '' ? $name : 'Integration', 0, 120));
            api_out(['token' => $token, 'webhook_leads' => lg_public_url('api/v1/?r=leads'), 'webhook_google' => lg_public_url('api/v1/?r=google_lead')], 201);

        case 'campaign_create':
            $in = api_input();
            $name = trim((string) ($in['name'] ?? ''));
            if ($name === '') api_fail('Give the campaign a name.', 422);
            $channel = in_array($in['channel'] ?? '', ['Email', 'WhatsApp', 'LinkedIn', 'Phone', 'Event', 'Ads'], true) ? $in['channel'] : 'Ads';
            execute_query("INSERT INTO campaigns (name, channel, status, budget, spent, utm_code, owner_user_id, created_at, updated_at)
                           VALUES (:n, :c, 'active', :b, :s, :utm, :u, NOW(), NOW())",
                [':n' => mb_substr($name, 0, 190), ':c' => $channel, ':b' => max(0, (float) ($in['budget'] ?? 0)),
                 ':s' => max(0, (float) ($in['spent'] ?? 0)), ':utm' => lg_slug($name), ':u' => $user['id']]);
            api_out(['id' => (int) db()->lastInsertId()], 201);

        default:
            api_fail('Unknown route. See the comment at the top of api/v1/index.php.', 404);
    }
} catch (InvalidArgumentException $exception) {
    api_fail($exception->getMessage(), 422);
} catch (Throwable $exception) {
    error_log('api: ' . $exception->getMessage());
    api_fail('Server error.', 500);
}
